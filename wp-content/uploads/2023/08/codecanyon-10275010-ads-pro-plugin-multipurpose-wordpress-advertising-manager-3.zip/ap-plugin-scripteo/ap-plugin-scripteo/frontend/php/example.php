<?php
echo "Example PHP Ad";