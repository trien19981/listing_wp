<?php
namespace ListarWP\Plugin\Libraries;

use ListarWP\Plugin\Models\Setting_Model;
use ListarWP\Plugin\Models\User_Model;
use Exception;

class Notify {
    /**
     * Setting key by email prefix
     * @var string
     */
    public static $email_setting_key = '';

    /**
     * recipient
     * @var string|array
     */
    public static $recipient = [];

    /**
     * Mobile push token
     *
     * @var array
     * @since 1.0.21
     */
    public static $mobile_push_token = [];

    /**
     * Map data with string pattern
     *
     * @param array $array
     * @param string $string
     * @return string
     * @since 1.0.12
     */
    static function pattern_replace($array, $string = '') {
        return listar_pattern_replace($array, $string);
    }

    /**
     * Send email notify
     * @param array $data
     * @since 1.0.12
     */
    public static function notify(array $data = [])
    {
        $headers = [];
        $notify_email_use = Setting_Model::get_option('email_use'); // common setting
        $email_use = Setting_Model::get_option('email_'.self::$email_setting_key.'_use'); // check base on case

        $mobile_push_use = Setting_Model::get_option('mobile_push_use'); // common setting
        $push_use = Setting_Model::get_option('push_'.self::$email_setting_key.'_use'); // check base on case

        // Disable notify all email/mobile push
        if(Setting_Model::get_option('email_debug_use')) {
            error_log('notify.email_use: ' . $notify_email_use . PHP_EOL);
            error_log('notify.mobile_push_use: ' . $mobile_push_use . PHP_EOL);
            error_log('notify.data: ' . json_encode($data) . PHP_EOL);
        }

        if(!$notify_email_use && !$mobile_push_use) {
            return;
        }

        // Meta data more
        $data['site_title'] = get_bloginfo();
        $data['site_address'] = get_site_url();

        $subject = Setting_Model::get_option('email_'.self::$email_setting_key.'_subject');
        $subject = self::pattern_replace($data, $subject);

        // === Email
        if($notify_email_use && ((int) $email_use === 1 || (string) $email_use === 'true')) {
            $content = Setting_Model::get_option('email_'.self::$email_setting_key.'_content');
            $content = self::pattern_replace($data, $content);
            
            // Email type
            $type = Setting_Model::get_option('email_'.self::$email_setting_key.'_type');

            // Header Format
            if($type == 'plain') {
                $headers[] = 'Content-Type: text/plain; charset=UTF-8';
            } else {
                $headers[] = 'Content-Type: text/html; charset=UTF-8';
            }

            // Debug
            if(Setting_Model::get_option('email_debug_use')) {
                error_log('wp_mail.email.recipient: ' . json_encode(self::$recipient) . PHP_EOL);
                error_log('wp_mail.email.subject: ' . $subject . PHP_EOL);
                error_log('wp_mail.email.content: ' . $content . PHP_EOL);
                error_log('wp_mail.email.headers: ' . json_encode($headers) . PHP_EOL);
            }
            
            // Send 
            if (self::$recipient && $subject && $content) {
                // Remove duplicate with array email    
                if(is_array(self::$recipient) && !empty(self::$recipient)) {
                    self::$recipient = array_unique(self::$recipient);
                }
                if(!wp_mail(self::$recipient, $subject, $content, $headers)) {
                    error_log('wp_mail.error: wp_mail() function is not working'.PHP_EOL);
                }
            } else {
                if(!self::$recipient) {
                    error_log('wp_mail.email: Missing recipient for send'.PHP_EOL);
                }
                if(!$subject) {
                    error_log('wp_mail.email: Missing subject for send'.PHP_EOL);
                }
                if(!$content) {
                    error_log('wp_mail.email: Missing content for send'.PHP_EOL);
                }
            }
        }

        // === Firebase
        if($mobile_push_use && ((int) $push_use === 1 || (string) $push_use === 'true')) {
            try {
                $content = Setting_Model::get_option('push_'.self::$email_setting_key.'_content');
                $content = self::pattern_replace($data, $content);
                $result = [];
                $mobile_push_debug_token = [];
                
                if($subject && $content) {
                    // Send Notification
                    if(Setting_Model::get_option('mobile_push_debug_use')) {
                        $mobile_push_debug_token = Setting_Model::get_option('mobile_push_debug_token');
                        if($mobile_push_debug_token) {
                            if(empty(self::$mobile_push_token)) {
                                self::$mobile_push_token = explode(',', $mobile_push_debug_token);
                            } else {
                                self::$mobile_push_token = array_merge(self::$mobile_push_token,
                                    explode(',', $mobile_push_debug_token));
                            }
                        }
                    }

                    if(empty(self::$mobile_push_token)) {
                        throw new Exception(__('Mobile push token is empty'));
                    }

                    $result = listar_send_device_notification_broadcast(
                        self::$mobile_push_token,
                        $subject,
                        $content,
                        $data
                    );
                }

                if(Setting_Model::get_option('mobile_push_debug_use')) {
                    error_log('firebase.token.debug: ' . json_encode($mobile_push_debug_token) . PHP_EOL);
                    error_log('firebase.token.production: ' . json_encode(self::$mobile_push_token) . PHP_EOL);
                    error_log('firebase.subject: ' . $subject . PHP_EOL);
                    error_log('firebase.data: ' . json_encode($data) . PHP_EOL);
                    error_log('firebase.result: ' . json_encode($result) . PHP_EOL);
                }
            } catch (Exception $e) {
                error_log('firebase.fail:'. $e->getMessage().PHP_EOL);
            }
        }
    }

    /**
     * Send notification when the booking is created
     * @param array $booking
     * @since 1.0.12
     */
    public static function notify_create_booking(array $booking = [])
    {   
        // Email setting key
        self::$email_setting_key = 'order';

        // Owner email
        if(isset($booking['author_email']) && !empty($booking['author_email'])) {
            self::$recipient[] = $booking['author_email'];
        }        

        // User email
        if(Setting_Model::get_option('email_order_user_use')) {
            self::$recipient[] = $booking['billing_email'];
        }

        // CC email setting
        $cc = Setting_Model::get_option('email_'.self::$email_setting_key.'_recipient');
        if(!$cc) {
            $cc = Setting_Model::get_option('email_recipient');
        }
        if(!empty($cc)) {
            self::$recipient[] = $cc;
        }

        // Mobile push
        $booking['type'] = 'booking';
        $booking['action'] = self::$email_setting_key;

        // Get mobile tokens
        if(isset($booking['author'])) {
            self::$mobile_push_token = User_Model::get_all_device_token(['include' => $booking['author']]);
        }

        // Trigger send notification
        self::notify($booking);
    }

    /**
     * Send notification when the booking is canceled
     * @param array $booking
     * @since 1.0.12
     */
    public static function notify_cancel_booking(array $booking = [])
    {
        self::$email_setting_key = 'cancel';

        // Owner email
        if(isset($booking['author_email']) && !empty($booking['author_email'])) {
            self::$recipient[] = $booking['author_email'];
        }

        // CC email setting
        $cc = Setting_Model::get_option('email_'.self::$email_setting_key.'_recipient');
        if(!$cc) {
            $cc = Setting_Model::get_option('email_recipient');
        }

        if(!empty($cc)) {
            self::$recipient[] = $cc;
        }

        // User 
        if(isset($booking['billing_email']) && !empty($booking['billing_email'])) {
            self::$recipient[] = $booking['billing_email'];
        } 

        // Mobile push
        $booking['type'] = 'booking';
        $booking['action'] = self::$email_setting_key;

        // Mobile token of both owner & user
        if(isset($booking['author']) && isset($booking['customer_user'])) {
            self::$mobile_push_token = User_Model::get_all_device_token(['include' => [
                $booking['author'],
                $booking['customer_user']
            ]]);
        }

        self::notify($booking);
    }

    /**
     * Send notification when fail booking with some reason
     * @param array $booking
     * @since 1.0.12
     */
    public static function notify_fail_booking(array $booking = [])
    {
        self::$email_setting_key = 'fail';
        
        // Owner email
        if(isset($booking['author_email']) && !empty($booking['author_email'])) {
            self::$recipient[] = $booking['author_email'];
        }

        // CC email setting
        $cc = Setting_Model::get_option('email_'.self::$email_setting_key.'_recipient');
        if(!$cc) {
            $cc = Setting_Model::get_option('email_recipient');
        }

        if(!empty($cc)) {
            self::$recipient[] = $cc;
        }

        // User 
        if(isset($booking['billing_email']) && !empty($booking['billing_email'])) {
            self::$recipient[] = $booking['billing_email'];
        } 

        // Mobile push
        $booking['type'] = 'booking';
        $booking['action'] = self::$email_setting_key;

        // Mobile token of both owner & user
        if(isset($booking['author']) && isset($booking['customer_user'])) {
            self::$mobile_push_token = User_Model::get_all_device_token(['include' => [
                $booking['author'],
                $booking['customer_user']
            ]]);
        }

        self::notify($booking);
    }

    /**
     * Send notification when the booking is completed
     * @param string $billing_email email of customer
     * @param array $booking
     * @since 1.0.12
     */
    public static function notify_complete_booking(string $billing_email = '', array $booking = [])
    {
        self::$email_setting_key = 'complete';

        // User email
        self::$recipient[] = $billing_email;

        // Owner email
        if(isset($booking['author_email']) && !empty($booking['author_email'])) {
            self::$recipient[] = $booking['author_email'];
        }

        // CC email setting
        $cc = Setting_Model::get_option('email_'.self::$email_setting_key.'_recipient');
        if(!$cc) {
            $cc = Setting_Model::get_option('email_recipient');
        }

        if(!empty($cc)) {
            self::$recipient[] = $cc;
        }

        // Mobile push
        $booking['type'] = 'booking';
        $booking['action'] = self::$email_setting_key;

        if(isset($booking['author']) && isset($booking['customer_user'])) {
            self::$mobile_push_token = User_Model::get_all_device_token(['include' => [
                $booking['author'],
                $booking['customer_user']
            ]]);
        }

        // Send
        self::notify($booking);
    }

    /**
     * Send notification when admin change booking status
     * @param array $booking
     * @param string $email_recipient
     * @since 1.0.21
     */
    public static function notify_status_booking(array $booking = [], $email_recipient = '')
    {
        self::$email_setting_key = 'status';

        // CC email setting
        $cc = Setting_Model::get_option('email_'.self::$email_setting_key.'_recipient');
        if(!$cc) {
            $cc = Setting_Model::get_option('email_recipient');
        }

        if(!empty($cc)) {
            self::$recipient[] = $cc;
        }

        if(!empty($email_recipient)) {
            self::$recipient[] = $email_recipient;
        }

        if(!empty(self::$recipient)) {
            // Mobile push
            $booking['type'] = 'booking';
            $booking['action'] = self::$email_setting_key;

            if(isset($booking['customer_user'])) {
                self::$mobile_push_token = User_Model::get_all_device_token(['include' => $booking['customer_user']]);
            }
            self::notify($booking);
        } else {
            error_log('notify_status_booking: Error is empty recipient');
        }
    }

    /**
     * Send notification when user submit new listing
     * - Add new via mobile 
     * - Add new via website 
     * 
     * @param array $post
     * @since 1.0.13
     */
    public static function notify_claim_submit(array $post)
    {
        self::$email_setting_key = 'claim_submit';
        self::$recipient = Setting_Model::get_option('email_'.self::$email_setting_key.'_recipient');
        if(!self::$recipient) {
            self::$recipient = Setting_Model::get_option('email_recipient');
        }

        // Mobile push
        $post['type'] = 'claim';
        $post['action'] = self::$email_setting_key;
        self::$mobile_push_token = User_Model::get_all_device_token([ 'role__in' => ['administrator']]);

        self::notify($post);
    }

    /**
     * Claim to request listing
     * @param array $data
     * @since 1.0.31
     */
    public static function notify_claim_request(array $data = [])
    {   
        // Email setting key
        self::$email_setting_key = 'claim_request';

        // Owner email
        if(isset($data['author_email']) && !empty($data['author_email'])) {
            self::$recipient[] = $data['author_email'];
        }        

        // User email
        if(Setting_Model::get_option('email_'.self::$email_setting_key.'_user_use')) {
            self::$recipient[] = $data['billing_email'];
        }

        // CC email setting
        $cc = Setting_Model::get_option('email_'.self::$email_setting_key.'_recipient');
        if(!$cc) {
            $cc = Setting_Model::get_option('email_recipient');
        }
        if(!empty($cc)) {
            self::$recipient[] = $cc;
        }

        // Mobile push
        $data['type'] = 'claim';
        $data['action'] = self::$email_setting_key;

        // Get mobile tokens
        if(isset($data['author'])) {
            self::$mobile_push_token = User_Model::get_all_device_token(['include' => $data['author']]);
        }

        // Trigger send notification
        self::notify($data);
    }

    /**
     * Request to claim is approved
     * 
     * @param array $post
     * @since 1.0.31
     */
    public static function notify_claim_approve(array $post = [])
    {
        self::$email_setting_key = 'claim_approve';

        // Get email of author
        $author = get_userdata($post['post_author']);
        self::$recipient = $author->data->user_email;

        // Mobile push
        $post['type'] = 'claim';
        $post['action'] = self::$email_setting_key;
        self::$mobile_push_token = User_Model::get_all_device_token(['include' => $post['post_author']]);

        self::notify($post);
    }

    /**
     * Claim listing is completed : change status or payment
     * @param array $data
     * @since 1.0.31
     */
    public static function notify_claim_complete(array $data = [])
    {
        self::$email_setting_key = 'claim_complete';

        // Owner email
        if(isset($data['author_email']) && !empty($data['author_email'])) {
            self::$recipient[] = $data['author_email'];
        }

        // CC email setting
        $cc = Setting_Model::get_option('email_'.self::$email_setting_key.'_recipient');
        if(!$cc) {
            $cc = Setting_Model::get_option('email_recipient');
        }

        if(!empty($cc)) {
            self::$recipient[] = $cc;
        }

        // Mobile push
        $data['type'] = 'claim';
        $data['action'] = self::$email_setting_key;

        if(isset($data['author']) && isset($data['customer_user'])) {
            self::$mobile_push_token = User_Model::get_all_device_token(['include' => [
                $data['author'],
                $data['customer_user']
            ]]);
        }

        // Send
        self::notify($data);
    }

    /**
     * Claim is cancelled when processing the payment
     * @param array $booking
     * @since 1.0.31
     */
    public static function notify_claim_cancel(array $data = [])
    {
        self::$email_setting_key = 'claim_cancel';

        // Owner email
        if(isset($data['author_email']) && !empty($data['author_email'])) {
            self::$recipient[] = $data['author_email'];
        }

        // CC email setting
        $cc = Setting_Model::get_option('email_'.self::$email_setting_key.'_recipient');
        if(!$cc) {
            $cc = Setting_Model::get_option('email_recipient');
        }

        if(!empty($cc)) {
            self::$recipient[] = $cc;
        }

        // User 
        if(isset($data['billing_email']) && !empty($data['billing_email'])) {
            self::$recipient[] = $data['billing_email'];
        } 

        // Mobile push
        $data['type'] = 'claim';
        $data['action'] = self::$email_setting_key;

        // Mobile token of both owner & user
        if(isset($data['author']) && isset($data['customer_user'])) {
            self::$mobile_push_token = User_Model::get_all_device_token(['include' => [
                $data['author'],
                $data['customer_user']
            ]]);
        }

        self::notify($data);
    }
}
