<?php
namespace ListarWP\Plugin\Libraries;

interface Api_Interface_Controller {
    public function register_routes();
}
