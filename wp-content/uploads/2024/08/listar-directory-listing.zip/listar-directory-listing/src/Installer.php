<?php
namespace ListarWP\Plugin;

class Installer {

    /**
     * Create tables
     */
    public static function create_tables()
    {
        self::create_booking_tables();
    }

    /**
     * Create new booking tables
     * @return bool
     */
    public static function create_booking_tables()
    {
        global $wpdb;

        // set the default character set and collation for the table
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Booking items
        $sql = "CREATE TABLE IF NOT EXISTS `{$wpdb->base_prefix}listar_booking_items` (
            `booking_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `booking_item_name` text COLLATE {$wpdb->collate} NOT NULL,
            `booking_item_type` varchar(200) COLLATE {$wpdb->collate} NOT NULL DEFAULT '',
            `booking_id` bigint(20) unsigned NOT NULL,
            PRIMARY KEY (`booking_item_id`) USING BTREE,
            KEY `order_id` (`booking_id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=1 $charset_collate;";

        dbDelta( $sql );

        // Booking item meta
        $sql = "CREATE TABLE IF NOT EXISTS `{$wpdb->base_prefix}listar_booking_itemmeta` (
            `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `booking_item_id` bigint(20) unsigned NOT NULL,
            `meta_key` varchar(255) COLLATE {$wpdb->collate} DEFAULT NULL,
            `meta_value` longtext COLLATE {$wpdb->collate} DEFAULT NULL,
            PRIMARY KEY (`meta_id`),
            KEY `order_item_id` (`booking_item_id`),
            KEY `meta_key` (`meta_key`(32))
        ) ENGINE=InnoDB AUTO_INCREMENT=1 $charset_collate;";

        dbDelta( $sql );

        // OTP 
        $sql = "CREATE TABLE `{$wpdb->base_prefix}listar_otp` (
            `id` int(20) NOT NULL AUTO_INCREMENT,
            `user_email` varchar(100) NOT NULL,
            `user_id` int(11) NOT NULL DEFAULT 0,
            `code` varchar(10) NOT NULL,
            `expired` enum('1','0') NOT NULL DEFAULT '0',
            `created_on` datetime NOT NULL,
            `ip` varchar(45) DEFAULT NULL,
            `expired_on` datetime NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=1 $charset_collate;";     

        $is_error = empty( $wpdb->last_error );
        
        return $is_error;
    }
}
